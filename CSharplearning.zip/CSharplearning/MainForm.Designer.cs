﻿namespace CSharplearning
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnManageBooks = new Button();
            btnAddBook = new Button();
            SuspendLayout();
            // 
            // btnManageBooks
            // 
            btnManageBooks.Location = new Point(45, 30);
            btnManageBooks.Name = "btnManageBooks";
            btnManageBooks.Size = new Size(137, 107);
            btnManageBooks.TabIndex = 0;
            btnManageBooks.Text = "Manage Books";
            btnManageBooks.UseVisualStyleBackColor = true;
            btnManageBooks.Click += btnManageBooks_Click;
            // 
            // btnAddBook
            // 
            btnAddBook.Location = new Point(45, 184);
            btnAddBook.Name = "btnAddBook";
            btnAddBook.Size = new Size(137, 107);
            btnAddBook.TabIndex = 1;
            btnAddBook.Text = "Add New Book";
            btnAddBook.UseVisualStyleBackColor = true;
            btnAddBook.Click += button2_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAddBook);
            Controls.Add(btnManageBooks);
            Name = "MainForm";
            Text = "MainForm";
            ResumeLayout(false);
        }

        #endregion

        private Button btnManageBooks;
        private Button btnAddBook;
    }
}